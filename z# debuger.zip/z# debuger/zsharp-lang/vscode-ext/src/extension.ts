import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';
import { spawn } from 'child_process';

export function activate(context: vscode.ExtensionContext) {
    console.log('Z# Debugger extension activated');

    // Register Run File command
    let runCommand = vscode.commands.registerCommand('zsharp.runFile', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No file open');
            return;
        }

        const filePath = editor.document.fileName;
        if (!filePath.endsWith('.z#')) {
            vscode.window.showErrorMessage('Current file is not a Z# file');
            return;
        }

        runZSharpFile(filePath);
    });

    // Register Check Syntax command
    let checkCommand = vscode.commands.registerCommand('zsharp.checkSyntax', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No file open');
            return;
        }

        const filePath = editor.document.fileName;
        checkZSharpSyntax(filePath);
    });

    // Register Start Debug command
    let debugCommand = vscode.commands.registerCommand('zsharp.startDebug', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No file open');
            return;
        }

        const filePath = editor.document.fileName;
        if (!filePath.endsWith('.z#')) {
            vscode.window.showErrorMessage('Current file is not a Z# file');
            return;
        }

        startDebugSession(filePath);
    });

    // Register hover provider for syntax help
    let hoverProvider = vscode.languages.registerHoverProvider('zsharp', {
        provideHover(document, position, token) {
            const line = document.lineAt(position.line);
            const word = document.getWordRangeAtPosition(position);

            if (!word) {
                return null;
            }

            const text = document.getText(word);
            const help = getKeywordHelp(text);

            if (help) {
                return new vscode.Hover(new vscode.MarkdownString(help));
            }

            return null;
        }
    });

    context.subscriptions.push(runCommand, checkCommand, debugCommand, hoverProvider);
}

function runZSharpFile(filePath: string) {
    const outputChannel = vscode.window.createOutputChannel('Z# Output');
    outputChannel.show();
    outputChannel.appendLine(`Running ${filePath}...`);

    const pythonPath = getPythonPath();
    const compilerPath = path.join(getExtensionPath(), '..', 'compiler', 'zsharp_compiler.py');

    const process = spawn(pythonPath, [compilerPath, filePath]);

    process.stdout.on('data', (data) => {
        outputChannel.append(data.toString());
    });

    process.stderr.on('data', (data) => {
        outputChannel.append(`[ERROR] ${data.toString()}`);
    });

    process.on('close', (code) => {
        outputChannel.appendLine(`\nProcess exited with code ${code}`);
    });
}

function checkZSharpSyntax(filePath: string) {
    const pythonPath = getPythonPath();
    const cliPath = path.join(getExtensionPath(), '..', 'cli', 'zsharp_cli.py');

    const process = spawn(pythonPath, [cliPath, 'check', filePath]);

    let output = '';
    let errorOutput = '';

    process.stdout.on('data', (data) => {
        output += data.toString();
    });

    process.stderr.on('data', (data) => {
        errorOutput += data.toString();
    });

    process.on('close', (code) => {
        if (code === 0) {
            vscode.window.showInformationMessage('✓ Syntax is valid');
        } else {
            vscode.window.showErrorMessage(`Syntax error: ${errorOutput || output}`);
        }
    });
}

function startDebugSession(filePath: string) {
    vscode.debug.startDebugging(
        vscode.workspace.getWorkspaceFolder(vscode.Uri.file(filePath)),
        {
            name: 'Z# Debug',
            type: 'zsharp',
            request: 'launch',
            program: filePath,
            stopOnEntry: true,
            console: 'integratedTerminal'
        }
    );
}

function getKeywordHelp(keyword: string): string | null {
    const help: { [key: string]: string } = {
        'include': '**include(lib)** - Import a library module',
        'get': '**get p*text*** - Print output to console',
        'loop': '**loop n { ... }** - Repeat code block n times',
        'check': '**check (condition) { ... }** - Conditional execution',
        'func': '**func name(params) { ... }** - Define a function',
        'ret': '**ret value** - Return from function'
    };

    return help[keyword] || null;
}

function getPythonPath(): string {
    const config = vscode.workspace.getConfiguration('python');
    return config.get<string>('pythonPath') || 'python3';
}

function getExtensionPath(): string {
    return vscode.extensions.getExtension('zsharp.zsharp-debugger')?.extensionPath || '';
}

export function deactivate() {
    console.log('Z# Debugger extension deactivated');
}
