#!/usr/bin/env python3
"""
Z# Debug Adapter for VS Code
Implements DAP (Debug Adapter Protocol) for z# debugging
"""

import sys
import json
import socket
from typing import Dict, Any, List
import struct

class DebugAdapter:
    """Debug Adapter for Z# language"""
    
    def __init__(self):
        self.seq = 1
        self.threads = {}
        self.breakpoints = {}
        self.variables = {}
        
    def handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Handle incoming DAP request"""
        command = request.get('command')
        args = request.get('arguments', {})
        
        if command == 'initialize':
            return self.handle_initialize(args)
        elif command == 'launch':
            return self.handle_launch(args)
        elif command == 'setBreakpoints':
            return self.handle_set_breakpoints(args)
        elif command == 'threads':
            return self.handle_threads()
        elif command == 'stackTrace':
            return self.handle_stack_trace(args)
        elif command == 'scopes':
            return self.handle_scopes(args)
        elif command == 'variables':
            return self.handle_variables(args)
        elif command == 'continue':
            return self.handle_continue(args)
        elif command == 'next':
            return self.handle_next(args)
        elif command == 'stepIn':
            return self.handle_step_in(args)
        elif command == 'stepOut':
            return self.handle_step_out(args)
        elif command == 'evaluate':
            return self.handle_evaluate(args)
        elif command == 'disconnect':
            return self.handle_disconnect(args)
        else:
            return {'success': False, 'message': f'Unknown command: {command}'}
    
    def handle_initialize(self, args: Dict) -> Dict[str, Any]:
        """Handle initialize request"""
        return {
            'capabilities': {
                'supportsConfigurationDoneRequest': True,
                'supportsSetVariable': True,
                'supportsSetExpression': True,
                'supportsEvaluateForHovers': True,
                'supportsConditionalBreakpoints': True,
                'supportsLogPoints': True,
                'supportsSteppingGranularity': True,
                'supportsRestartFrame': False,
                'supportsExceptionFilterOptions': False,
                'supportsValueFormattingOptions': True,
                'supportsHitConditionalBreakpoints': True,
                'supportsClipboardContext': False,
                'supportsRestartRequest': False,
                'supportsTerminateRequest': False,
                'supportsTerminateThreadsRequest': False,
                'supportsModulesRequest': False
            }
        }
    
    def handle_launch(self, args: Dict) -> Dict[str, Any]:
        """Handle launch request"""
        program = args.get('program')
        stop_on_entry = args.get('stopOnEntry', False)
        
        # In a real implementation, we would parse and execute the z# program
        # For now, we'll just return success
        
        return {
            'success': True,
            'message': f'Launched Z# debugger for {program}'
        }
    
    def handle_set_breakpoints(self, args: Dict) -> Dict[str, Any]:
        """Handle setBreakpoints request"""
        source = args.get('source', {})
        lines = args.get('lines', [])
        
        file_path = source.get('path', '')
        self.breakpoints[file_path] = lines
        
        return {
            'breakpoints': [{'verified': True, 'line': line} for line in lines]
        }
    
    def handle_threads(self) -> Dict[str, Any]:
        """Handle threads request"""
        return {
            'threads': [
                {'id': 1, 'name': 'main'}
            ]
        }
    
    def handle_stack_trace(self, args: Dict) -> Dict[str, Any]:
        """Handle stackTrace request"""
        thread_id = args.get('threadId', 1)
        
        return {
            'stackFrames': [
                {
                    'id': 1,
                    'name': 'main',
                    'source': {'path': '<unknown>'},
                    'line': 1,
                    'column': 0
                }
            ],
            'totalFrames': 1
        }
    
    def handle_scopes(self, args: Dict) -> Dict[str, Any]:
        """Handle scopes request"""
        return {
            'scopes': [
                {
                    'name': 'Local',
                    'variablesReference': 1,
                    'expensive': False
                }
            ]
        }
    
    def handle_variables(self, args: Dict) -> Dict[str, Any]:
        """Handle variables request"""
        variables_ref = args.get('variablesReference', 1)
        
        # Return mock variables
        return {
            'variables': [
                {'name': 'example', 'value': '42', 'type': 'int', 'variablesReference': 0}
            ]
        }
    
    def handle_continue(self, args: Dict) -> Dict[str, Any]:
        """Handle continue request"""
        return {'allThreadsContinued': True}
    
    def handle_next(self, args: Dict) -> Dict[str, Any]:
        """Handle next request"""
        return {}
    
    def handle_step_in(self, args: Dict) -> Dict[str, Any]:
        """Handle stepIn request"""
        return {}
    
    def handle_step_out(self, args: Dict) -> Dict[str, Any]:
        """Handle stepOut request"""
        return {}
    
    def handle_evaluate(self, args: Dict) -> Dict[str, Any]:
        """Handle evaluate request"""
        expression = args.get('expression', '')
        
        return {
            'result': f'Evaluated: {expression}',
            'type': 'string',
            'variablesReference': 0
        }
    
    def handle_disconnect(self, args: Dict) -> Dict[str, Any]:
        """Handle disconnect request"""
        return {'success': True}

def main():
    """Main debug adapter entry point"""
    adapter = DebugAdapter()
    
    # Read stdin in message format
    while True:
        try:
            # Read headers
            headers = {}
            while True:
                line = sys.stdin.readline()
                if not line:
                    return
                line = line.strip()
                if not line:
                    break
                key, value = line.split(':', 1)
                headers[key.strip()] = value.strip()
            
            # Read body
            content_length = int(headers.get('Content-Length', 0))
            if content_length == 0:
                continue
            
            body = sys.stdin.read(content_length)
            message = json.loads(body)
            
            # Handle message
            response = {'seq': adapter.seq, 'type': 'response'}
            adapter.seq += 1
            
            if message.get('type') == 'request':
                response['command'] = message.get('command')
                response.update(adapter.handle_request(message))
            
            # Send response
            response_str = json.dumps(response)
            response_bytes = response_str.encode('utf-8')
            
            sys.stdout.write(f'Content-Length: {len(response_bytes)}\r\n')
            sys.stdout.write('Content-Type: application/json\r\n')
            sys.stdout.write('\r\n')
            sys.stdout.write(response_str)
            sys.stdout.flush()
        
        except Exception as e:
            print(f'Error: {e}', file=sys.stderr)

if __name__ == '__main__':
    main()
