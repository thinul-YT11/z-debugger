#!/usr/bin/env python3
"""
Z# Language Launcher
Entry point for the Z# IDE/Debugger
"""

import sys
import os

# Add the app's resources to Python path
app_resources = os.path.dirname(os.path.abspath(__file__))
if not app_resources.endswith('Resources'):
    app_resources = os.path.join(app_resources, 'Resources')

if os.path.exists(app_resources):
    sys.path.insert(0, app_resources)

from cli.zsharp_cli import main

if __name__ == "__main__":
    # If no arguments, show help
    if len(sys.argv) == 1:
        sys.argv.append('--help')
    
    main()
