# Z# Programming Language - Quick Start Guide

## ✨ What is Z#?

Z# is a simple, elegant programming language with full VS Code debugging support. It's designed to be easy to learn and use, with a clean syntax that's simple to understand.

## 📦 Installation

### Option 1: Using the .app File (Recommended)

The Z# .app file is located at:
```
/Users/kaushalyatennakoon/Desktop/untitled folder/zsharp-lang/dist/Z-Sharp.app
```

To install Z#:

1. **Copy the app to Applications** (optional):
   ```bash
   cp -r "dist/Z-Sharp.app" /Applications/
   ```

2. **Create command-line tools**:
   ```bash
   mkdir -p ~/.zsharp
   cp -r compiler cli vscode-ext ~/.zsharp/
   
   # Create zsharp command
   sudo tee /usr/local/bin/zsharp > /dev/null << 'EOF'
   #!/bin/bash
   exec python3 << 'PYTHON_EOF'
   import sys
   import os
   sys.path.insert(0, os.path.expanduser("~/.zsharp"))
   from cli.zsharp_cli import main
   main()
   PYTHON_EOF
   EOF
   
   sudo chmod +x /usr/local/bin/zsharp
   ```

3. **Test the installation**:
   ```bash
   zsharp --version
   ```

## 🚀 Quick Start

### 1. Create a Z# File
Create `hello.z#`:
```z#
include(zsharp)

get p*Hello, Z#!*
```

### 2. Run It
```bash
zsharp run hello.z#
```

Output:
```
Hello, Z#!
```

## 📚 Language Features

### Variables
```z#
name = *Alice*
age = 25
score = 95.5
```

### Print Output
```z#
get p*Hello, World!*
```

### Loops
```z#
loop 5 {
    get p*Welcome*
}
```

### Conditional Statements
```z#
check (age > 18) {
    get p*You are an adult*
}
```

### Functions
```z#
func greet(name) {
    get p*Hello, *
    get p*name*
}

greet(*Bob*)
```

### Math Operations
```z#
a = 10
b = 5
sum = a + b
product = a * b
```

## 🔧 CLI Commands

```bash
# Run a program
zsharp run program.z#

# Build to bytecode
zsharp build program.z#

# Check syntax
zsharp check program.z#

# Debug interactively
zsharp debug program.z#

# Create new project
zsharp create myproject
```

## 🐛 Debugging

### Using the CLI Debugger
```bash
zsharp debug myfile.z#
```

### Using VS Code
1. Install the Z# extension from the VS Code marketplace (or use the bundled one)
2. Open a `.z#` file in VS Code
3. Press `Cmd+Shift+D` to start debugging
4. Set breakpoints by clicking on line numbers
5. Use the debug controls to step through code

## 📂 Project Structure

After running `zsharp create myproject`:
```
myproject/
├── main.z#
└── README.md
```

## 📝 Examples

### Example 1: Counting
```z#
include(zsharp)

get p*Numbers 1-5:*

loop 5 {
    get p*1*
}
```

### Example 2: Function
```z#
include(zsharp)

func add(a, b) {
    result = a + b
    ret result
}

sum = add(3, 7)
get p*3 + 7 = *
get p*10*
```

### Example 3: Conditional
```z#
include(zsharp)

age = 25

check (age >= 18) {
    get p*Legal age*
}

check (age < 18) {
    get p*Minor*
}
```

## 📖 More Information

- **Syntax**: See `/examples/` directory for sample programs
- **Documentation**: Check `README.md` for full documentation
- **Issues**: Report bugs on GitHub

## 🎯 Next Steps

1. **Run Examples**: 
   ```bash
   zsharp run examples/hello.z#
   zsharp run examples/functions.z#
   zsharp run examples/math.z#
   ```

2. **Create Your First Program**: Make a new `.z#` file and start coding!

3. **Debug Your Code**: Use `zsharp debug` or VS Code debugger

4. **Learn More**: Check out the full documentation in `README.md`

## 💡 Tips

- Always start with `include(zsharp)` for basic programs
- Use `get p*text*` to print output
- Comments are written with `//`
- Save files with `.z#` extension
- The debugger works best with VS Code

## 🆘 Troubleshooting

**Command not found**: Make sure `/usr/local/bin` is in your PATH
```bash
echo $PATH
```

**Permission denied**: Set execute permissions
```bash
chmod +x /usr/local/bin/zsharp
```

**File not found**: Use absolute paths or relative paths from the correct directory
```bash
zsharp run /full/path/to/file.z#
```

Enjoy programming in Z#! 🎉
