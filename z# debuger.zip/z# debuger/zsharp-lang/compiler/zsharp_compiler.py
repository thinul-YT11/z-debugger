#!/usr/bin/env python3
"""
Z# Programming Language Compiler
Interprets and debugs z# source code
"""

import re
import sys
import json
from typing import Any, Dict, List, Optional
from enum import Enum

class TokenType(Enum):
    """Token types for z# language"""
    INCLUDE = "INCLUDE"
    GET = "GET"
    IDENTIFIER = "IDENTIFIER"
    STRING = "STRING"
    NUMBER = "NUMBER"
    OPERATOR = "OPERATOR"
    NEWLINE = "NEWLINE"
    EOF = "EOF"
    LPAREN = "LPAREN"
    RPAREN = "RPAREN"
    LBRACE = "LBRACE"
    RBRACE = "RBRACE"
    SEMICOLON = "SEMICOLON"
    COMMA = "COMMA"
    ASSIGN = "ASSIGN"
    PLUS = "PLUS"
    MINUS = "MINUS"
    MULTIPLY = "MULTIPLY"
    DIVIDE = "DIVIDE"
    LOOP = "LOOP"
    CHECK = "CHECK"
    RETURN = "RETURN"
    FUNCTION = "FUNCTION"

class Token:
    """Represents a single token"""
    def __init__(self, type_: TokenType, value: Any, line: int, col: int):
        self.type = type_
        self.value = value
        self.line = line
        self.col = col
    
    def __repr__(self):
        return f"Token({self.type}, {self.value!r}, {self.line}, {self.col})"

class Lexer:
    """Tokenizes z# source code"""
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.col = 1
        self.tokens: List[Token] = []
    
    def tokenize(self) -> List[Token]:
        """Convert source code into tokens"""
        while self.pos < len(self.source):
            self._skip_whitespace_and_comments()
            if self.pos >= len(self.source):
                break
            
            if self._match_newline():
                continue
            elif self._match_string():
                continue
            elif self._match_number():
                continue
            elif self._check_keyword():
                continue
            elif self._match_symbol():
                continue
            elif self._match_identifier():
                continue
            else:
                raise SyntaxError(f"Unexpected character '{self.source[self.pos]}' at {self.line}:{self.col}")
        
        self.tokens.append(Token(TokenType.EOF, None, self.line, self.col))
        return self.tokens
    
    def _current_char(self) -> Optional[str]:
        if self.pos >= len(self.source):
            return None
        return self.source[self.pos]
    
    def _peek_char(self, offset=1) -> Optional[str]:
        pos = self.pos + offset
        if pos >= len(self.source):
            return None
        return self.source[pos]
    
    def _advance(self) -> str:
        char = self.source[self.pos]
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return char
    
    def _skip_whitespace_and_comments(self):
        while self.pos < len(self.source):
            if self.source[self.pos] in ' \t\r':
                self._advance()
            elif self.source[self.pos:self.pos+2] == '//':
                while self._current_char() and self._current_char() != '\n':
                    self._advance()
            else:
                break
    
    def _match_newline(self) -> bool:
        if self._current_char() == '\n':
            self._advance()
            return True
        return False
    
    def _check_keyword(self) -> bool:
        """Check for and match keywords"""
        if not self._current_char() or not self._current_char().isalpha() and self._current_char() != '_':
            return False
        
        start = self.pos
        start_col = self.col
        while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] == '_'):
            self._advance()
        
        word = self.source[start:self.pos]
        
        if word == "include":
            self.tokens.append(Token(TokenType.INCLUDE, word, self.line, start_col))
            return True
        elif word == "get":
            self.tokens.append(Token(TokenType.GET, word, self.line, start_col))
            return True
        elif word == "loop":
            self.tokens.append(Token(TokenType.LOOP, word, self.line, start_col))
            return True
        elif word == "check":
            self.tokens.append(Token(TokenType.CHECK, word, self.line, start_col))
            return True
        elif word == "ret":
            self.tokens.append(Token(TokenType.RETURN, word, self.line, start_col))
            return True
        elif word == "func":
            self.tokens.append(Token(TokenType.FUNCTION, word, self.line, start_col))
            return True
        else:
            # Not a keyword, rewind and let identifier handle it
            self.pos = start
            self.col = start_col
            return False
    
    def _match_identifier(self) -> bool:
        if not self._current_char() or not self._current_char().isalpha() and self._current_char() != '_':
            return False
        
        start = self.pos
        start_col = self.col
        while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] == '_'):
            self._advance()
        
        identifier = self.source[start:self.pos]
        self.tokens.append(Token(TokenType.IDENTIFIER, identifier, self.line, start_col))
        return True
    
    def _match_string(self) -> bool:
        if self._current_char() != '*':
            return False
        
        start_col = self.col
        self._advance()  # Skip opening *
        start = self.pos
        
        while self.pos < len(self.source) and self._current_char() != '*':
            self._advance()
        
        if self._current_char() != '*':
            raise SyntaxError(f"Unterminated string at {self.line}:{start_col}")
        
        string_val = self.source[start:self.pos]
        self._advance()  # Skip closing *
        self.tokens.append(Token(TokenType.STRING, string_val, self.line, start_col))
        return True
    
    def _match_number(self) -> bool:
        if not self._current_char() or not self._current_char().isdigit():
            return False
        
        start = self.pos
        start_col = self.col
        while self.pos < len(self.source) and (self.source[self.pos].isdigit() or self.source[self.pos] == '.'):
            self._advance()
        
        num_str = self.source[start:self.pos]
        if '.' in num_str:
            num = float(num_str)
        else:
            num = int(num_str)
        self.tokens.append(Token(TokenType.NUMBER, num, self.line, start_col))
        return True
    
    def _match_operator(self) -> bool:
        char = self._current_char()
        if char == '+':
            self._advance()
            self.tokens.append(Token(TokenType.PLUS, '+', self.line, self.col - 1))
            return True
        elif char == '-':
            self._advance()
            self.tokens.append(Token(TokenType.MINUS, '-', self.line, self.col - 1))
            return True
        elif char == '*':
            self._advance()
            self.tokens.append(Token(TokenType.MULTIPLY, '*', self.line, self.col - 1))
            return True
        elif char == '/':
            self._advance()
            self.tokens.append(Token(TokenType.DIVIDE, '/', self.line, self.col - 1))
            return True
        elif char == '=':
            self._advance()
            self.tokens.append(Token(TokenType.ASSIGN, '=', self.line, self.col - 1))
            return True
        return False
    
    def _match_symbol(self) -> bool:
        char = self._current_char()
        if char == '(':
            self._advance()
            self.tokens.append(Token(TokenType.LPAREN, '(', self.line, self.col - 1))
            return True
        elif char == ')':
            self._advance()
            self.tokens.append(Token(TokenType.RPAREN, ')', self.line, self.col - 1))
            return True
        elif char == '{':
            self._advance()
            self.tokens.append(Token(TokenType.LBRACE, '{', self.line, self.col - 1))
            return True
        elif char == '}':
            self._advance()
            self.tokens.append(Token(TokenType.RBRACE, '}', self.line, self.col - 1))
            return True
        elif char == ';':
            self._advance()
            self.tokens.append(Token(TokenType.SEMICOLON, ';', self.line, self.col - 1))
            return True
        elif char == ',':
            self._advance()
            self.tokens.append(Token(TokenType.COMMA, ',', self.line, self.col - 1))
            return True
        return False

class Parser:
    """Parses tokens into an AST"""
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
    
    def parse(self) -> Dict[str, Any]:
        """Parse tokens into an AST"""
        statements = []
        while not self._is_at_end():
            stmt = self._parse_statement()
            if stmt:
                statements.append(stmt)
        return {"type": "program", "statements": statements}
    
    def _current_token(self) -> Token:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]  # EOF
    
    def _peek_token(self, offset=1) -> Token:
        pos = self.pos + offset
        if pos < len(self.tokens):
            return self.tokens[pos]
        return self.tokens[-1]
    
    def _advance(self) -> Token:
        token = self._current_token()
        if not self._is_at_end():
            self.pos += 1
        return token
    
    def _is_at_end(self) -> bool:
        return self._current_token().type == TokenType.EOF
    
    def _match(self, *types: TokenType) -> bool:
        if self._current_token().type in types:
            return True
        return False
    
    def _consume(self, type_: TokenType, message: str) -> Token:
        if self._current_token().type != type_:
            raise SyntaxError(f"{message} at {self._current_token().line}:{self._current_token().col}")
        return self._advance()
    
    def _parse_statement(self) -> Optional[Dict[str, Any]]:
        if self._match(TokenType.INCLUDE):
            return self._parse_include()
        elif self._match(TokenType.GET):
            return self._parse_get()
        elif self._match(TokenType.FUNCTION):
            return self._parse_function()
        elif self._match(TokenType.LOOP):
            return self._parse_loop()
        elif self._match(TokenType.CHECK):
            return self._parse_check()
        elif self._match(TokenType.RETURN):
            return self._parse_return()
        elif self._match(TokenType.IDENTIFIER):
            return self._parse_assignment()
        elif self._match(TokenType.SEMICOLON):
            self._advance()
            return None
        return None
    
    def _parse_include(self) -> Dict[str, Any]:
        self._consume(TokenType.INCLUDE, "Expected 'include'")
        self._consume(TokenType.LPAREN, "Expected '(' after include")
        library = self._consume(TokenType.IDENTIFIER, "Expected library name")
        self._consume(TokenType.RPAREN, "Expected ')' after library")
        return {
            "type": "include",
            "library": library.value,
            "line": library.line
        }
    
    def _parse_get(self) -> Dict[str, Any]:
        self._consume(TokenType.GET, "Expected 'get'")
        self._consume(TokenType.IDENTIFIER, "Expected variable/function after get")
        # Parse p* or other prefix
        return {
            "type": "get",
            "expr": self._parse_expression()
        }
    
    def _parse_expression(self) -> Dict[str, Any]:
        return self._parse_additive()
    
    def _parse_additive(self) -> Dict[str, Any]:
        expr = self._parse_multiplicative()
        
        while self._match(TokenType.PLUS, TokenType.MINUS):
            op = self._advance()
            right = self._parse_multiplicative()
            expr = {
                "type": "binary_op",
                "op": op.value,
                "left": expr,
                "right": right
            }
        return expr
    
    def _parse_multiplicative(self) -> Dict[str, Any]:
        expr = self._parse_primary()
        
        while self._match(TokenType.MULTIPLY, TokenType.DIVIDE):
            op = self._advance()
            right = self._parse_primary()
            expr = {
                "type": "binary_op",
                "op": op.value,
                "left": expr,
                "right": right
            }
        return expr
    
    def _parse_primary(self) -> Dict[str, Any]:
        if self._match(TokenType.STRING):
            token = self._advance()
            return {"type": "string", "value": token.value}
        elif self._match(TokenType.NUMBER):
            token = self._advance()
            return {"type": "number", "value": token.value}
        elif self._match(TokenType.IDENTIFIER):
            token = self._advance()
            if self._match(TokenType.LPAREN):
                return self._parse_function_call(token.value)
            return {"type": "identifier", "value": token.value}
        elif self._match(TokenType.LPAREN):
            self._advance()
            expr = self._parse_expression()
            self._consume(TokenType.RPAREN, "Expected ')' after expression")
            return expr
        raise SyntaxError(f"Unexpected token: {self._current_token()}")
    
    def _parse_function_call(self, name: str) -> Dict[str, Any]:
        self._consume(TokenType.LPAREN, "Expected '('")
        args = []
        if not self._match(TokenType.RPAREN):
            args.append(self._parse_expression())
            while self._match(TokenType.COMMA):
                self._advance()
                args.append(self._parse_expression())
        self._consume(TokenType.RPAREN, "Expected ')'")
        return {
            "type": "call",
            "name": name,
            "args": args
        }
    
    def _parse_assignment(self) -> Dict[str, Any]:
        var = self._consume(TokenType.IDENTIFIER, "Expected identifier")
        self._consume(TokenType.ASSIGN, "Expected '=' in assignment")
        expr = self._parse_expression()
        return {
            "type": "assignment",
            "var": var.value,
            "expr": expr,
            "line": var.line
        }
    
    def _parse_function(self) -> Dict[str, Any]:
        self._advance()  # consume 'func'
        name = self._consume(TokenType.IDENTIFIER, "Expected function name")
        self._consume(TokenType.LPAREN, "Expected '(' after function name")
        params = []
        if not self._match(TokenType.RPAREN):
            params.append(self._advance().value)
            while self._match(TokenType.COMMA):
                self._advance()
                params.append(self._advance().value)
        self._consume(TokenType.RPAREN, "Expected ')'")
        self._consume(TokenType.LBRACE, "Expected '{'")
        statements = []
        while not self._match(TokenType.RBRACE):
            stmt = self._parse_statement()
            if stmt:
                statements.append(stmt)
        self._consume(TokenType.RBRACE, "Expected '}'")
        return {
            "type": "function",
            "name": name.value,
            "params": params,
            "body": statements,
            "line": name.line
        }
    
    def _parse_loop(self) -> Dict[str, Any]:
        self._advance()  # consume 'loop'
        times = self._parse_primary()
        self._consume(TokenType.LBRACE, "Expected '{'")
        statements = []
        while not self._match(TokenType.RBRACE):
            stmt = self._parse_statement()
            if stmt:
                statements.append(stmt)
        self._consume(TokenType.RBRACE, "Expected '}'")
        return {
            "type": "loop",
            "times": times,
            "body": statements
        }
    
    def _parse_check(self) -> Dict[str, Any]:
        self._advance()  # consume 'check'
        condition = self._parse_expression()
        self._consume(TokenType.LBRACE, "Expected '{'")
        statements = []
        while not self._match(TokenType.RBRACE):
            stmt = self._parse_statement()
            if stmt:
                statements.append(stmt)
        self._consume(TokenType.RBRACE, "Expected '}'")
        return {
            "type": "if",
            "condition": condition,
            "body": statements
        }
    
    def _parse_return(self) -> Dict[str, Any]:
        self._advance()  # consume 'ret'
        expr = self._parse_expression()
        return {
            "type": "return",
            "value": expr
        }

class Interpreter:
    """Executes z# code"""
    def __init__(self, debug=False):
        self.variables: Dict[str, Any] = {}
        self.functions: Dict[str, Dict[str, Any]] = {}
        self.debug = debug
        self.output: List[str] = []
        self.call_stack: List[str] = []
        self.breakpoints: List[int] = []
    
    def execute(self, ast: Dict[str, Any]) -> List[str]:
        """Execute the AST and return output"""
        for statement in ast["statements"]:
            self._execute_statement(statement)
        return self.output
    
    def _execute_statement(self, stmt: Dict[str, Any]) -> Any:
        if stmt["type"] == "include":
            if self.debug:
                print(f"[DEBUG] Including library: {stmt['library']}")
            return None
        elif stmt["type"] == "get":
            result = self._evaluate(stmt["expr"])
            self.output.append(str(result))
            return result
        elif stmt["type"] == "assignment":
            value = self._evaluate(stmt["expr"])
            self.variables[stmt["var"]] = value
            if self.debug:
                print(f"[DEBUG] {stmt['var']} = {value}")
            return value
        elif stmt["type"] == "function":
            self.functions[stmt["name"]] = stmt
            if self.debug:
                print(f"[DEBUG] Defined function: {stmt['name']}")
            return None
        elif stmt["type"] == "loop":
            times = self._evaluate(stmt["times"])
            for i in range(int(times)):
                for body_stmt in stmt["body"]:
                    self._execute_statement(body_stmt)
            return None
        elif stmt["type"] == "if":
            condition = self._evaluate(stmt["condition"])
            if condition:
                for body_stmt in stmt["body"]:
                    self._execute_statement(body_stmt)
            return None
        elif stmt["type"] == "return":
            result = self._evaluate(stmt["value"])
            if self.debug:
                print(f"[DEBUG] Return: {result}")
            return result
        return None
    
    def _evaluate(self, expr: Dict[str, Any]) -> Any:
        if expr["type"] == "string":
            return expr["value"]
        elif expr["type"] == "number":
            return expr["value"]
        elif expr["type"] == "identifier":
            if expr["value"] in self.variables:
                return self.variables[expr["value"]]
            raise NameError(f"Undefined variable: {expr['value']}")
        elif expr["type"] == "binary_op":
            left = self._evaluate(expr["left"])
            right = self._evaluate(expr["right"])
            op = expr["op"]
            if op == "+":
                return left + right
            elif op == "-":
                return left - right
            elif op == "*":
                return left * right
            elif op == "/":
                if right == 0:
                    raise RuntimeError("Division by zero")
                return left / right
        elif expr["type"] == "call":
            return self._call_function(expr["name"], expr["args"])
        return None
    
    def _call_function(self, name: str, args: List[Dict[str, Any]]) -> Any:
        if name == "len":
            arg = self._evaluate(args[0])
            return len(str(arg))
        elif name == "type":
            arg = self._evaluate(args[0])
            return type(arg).__name__
        elif name in self.functions:
            func_def = self.functions[name]
            old_vars = self.variables.copy()
            for i, param in enumerate(func_def["params"]):
                if i < len(args):
                    self.variables[param] = self._evaluate(args[i])
            result = None
            for stmt in func_def["body"]:
                result = self._execute_statement(stmt)
            self.variables = old_vars
            return result
        raise NameError(f"Undefined function: {name}")

def compile_and_run(source: str, debug=False) -> List[str]:
    """Compile and execute z# source code"""
    # Tokenize
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    
    if debug:
        print("[DEBUG] Tokens:")
        for token in tokens[:20]:  # Show first 20 tokens
            print(f"  {token}")
    
    # Parse
    parser = Parser(tokens)
    ast = parser.parse()
    
    if debug:
        print("[DEBUG] AST:")
        print(json.dumps(ast, indent=2)[:500])  # Show first 500 chars
    
    # Execute
    interpreter = Interpreter(debug=debug)
    output = interpreter.execute(ast)
    return output

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python zsharp_compiler.py <file.z#> [--debug]")
        sys.exit(1)
    
    filename = sys.argv[1]
    debug_mode = "--debug" in sys.argv
    
    try:
        with open(filename, 'r') as f:
            source = f.read()
        
        output = compile_and_run(source, debug=debug_mode)
        for line in output:
            print(line)
    
    except FileNotFoundError:
        print(f"Error: File not found: {filename}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
