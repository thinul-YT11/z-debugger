#!/usr/bin/env python3
"""
Z# Language CLI Tool
Provides commands for running, compiling, and debugging z# code
"""

import sys
import os
import argparse
import json
from pathlib import Path

# Add compiler to path
compiler_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, compiler_path)

from compiler.zsharp_compiler import compile_and_run, Lexer, Parser, Interpreter

def main():
    parser = argparse.ArgumentParser(
        description="Z# Programming Language CLI",
        prog="zsharp"
    )
    
    parser.add_argument("--version", action="version", version="z# 0.1.0")
    
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run a z# file")
    run_parser.add_argument("file", help="Z# source file to run")
    run_parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    
    # Build command
    build_parser = subparsers.add_parser("build", help="Build a z# file")
    build_parser.add_argument("file", help="Z# source file to build")
    build_parser.add_argument("-o", "--output", help="Output file name")
    
    # Check command
    check_parser = subparsers.add_parser("check", help="Check z# file for syntax errors")
    check_parser.add_argument("file", help="Z# source file to check")
    
    # Debug command
    debug_parser = subparsers.add_parser("debug", help="Debug a z# file interactively")
    debug_parser.add_argument("file", help="Z# source file to debug")
    
    # Create command for new project
    create_parser = subparsers.add_parser("create", help="Create a new z# project")
    create_parser.add_argument("name", help="Project name")
    
    args = parser.parse_args()
    
    if args.command == "run":
        cmd_run(args.file, args.debug)
    elif args.command == "build":
        cmd_build(args.file, args.output)
    elif args.command == "check":
        cmd_check(args.file)
    elif args.command == "debug":
        cmd_debug(args.file)
    elif args.command == "create":
        cmd_create(args.name)
    else:
        parser.print_help()

def cmd_run(filename: str, debug: bool = False):
    """Run a z# file"""
    try:
        if not os.path.exists(filename):
            print(f"Error: File not found: {filename}")
            sys.exit(1)
        
        with open(filename, 'r') as f:
            source = f.read()
        
        print(f"Running {filename}...")
        output = compile_and_run(source, debug=debug)
        
        for line in output:
            print(line)
    
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

def cmd_build(filename: str, output: str = None):
    """Build a z# file to bytecode"""
    try:
        if not os.path.exists(filename):
            print(f"Error: File not found: {filename}")
            sys.exit(1)
        
        if output is None:
            output = filename.replace(".z#", ".zbc")
        
        with open(filename, 'r') as f:
            source = f.read()
        
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        
        with open(output, 'w') as f:
            json.dump(ast, f, indent=2)
        
        print(f"Built {filename} to {output}")
    
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

def cmd_check(filename: str):
    """Check z# file for syntax errors"""
    try:
        if not os.path.exists(filename):
            print(f"Error: File not found: {filename}")
            sys.exit(1)
        
        with open(filename, 'r') as f:
            source = f.read()
        
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        
        print(f"✓ {filename} is valid")
    
    except Exception as e:
        print(f"Syntax Error in {filename}: {e}")
        sys.exit(1)

def cmd_debug(filename: str):
    """Debug a z# file interactively"""
    try:
        if not os.path.exists(filename):
            print(f"Error: File not found: {filename}")
            sys.exit(1)
        
        with open(filename, 'r') as f:
            source = f.read()
        
        # Create interpreter with debug enabled
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        parser = Parser(tokens)
        ast = parser.parse()
        interpreter = Interpreter(debug=True)
        
        print(f"Debugging {filename} (type 'help' for commands)")
        
        output = interpreter.execute(ast)
        for line in output:
            print(line)
    
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

def cmd_create(project_name: str):
    """Create a new z# project"""
    try:
        Path(project_name).mkdir(exist_ok=True)
        
        # Create main.z#
        main_file = os.path.join(project_name, "main.z#")
        with open(main_file, 'w') as f:
            f.write("""include(zsharp)

get p*Hello, z# world!*

func greet(name) {
    get p*Hello, *
    get p*name*
}

greet(*User*)
""")
        
        # Create README
        readme_file = os.path.join(project_name, "README.md")
        with open(readme_file, 'w') as f:
            f.write(f"# {project_name}\n\nA Z# programming project\n")
        
        print(f"Created new z# project: {project_name}")
        print(f"  - {main_file}")
        print(f"  - {readme_file}")
    
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
