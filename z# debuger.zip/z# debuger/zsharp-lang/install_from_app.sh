#!/bin/bash
# Z# Installation Helper
# Installs Z# from the .app file to /usr/local/bin and ~/.zsharp

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_info() {
    echo -e "${BLUE}ℹ ${1}${NC}"
}

print_success() {
    echo -e "${GREEN}✓ ${1}${NC}"
}

print_error() {
    echo -e "${RED}✗ ${1}${NC}"
}

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

print_info "Z# Programming Language Installation"
echo "========================================"
echo ""

# Check if Z-Sharp.app exists
if [ ! -d "$SCRIPT_DIR/dist/Z-Sharp.app" ]; then
    print_error "Z-Sharp.app not found!"
    print_info "Run './build_app.sh' first to build the application"
    exit 1
fi

# Create installation directory
print_info "Creating installation directory..."
mkdir -p "$HOME/.zsharp"
print_success "Created $HOME/.zsharp"

# Copy files
print_info "Installing Z# files..."
cp -r "$SCRIPT_DIR/compiler" "$HOME/.zsharp/" 2>/dev/null && print_success "Compiler installed" || true
cp -r "$SCRIPT_DIR/cli" "$HOME/.zsharp/" 2>/dev/null && print_success "CLI installed" || true
cp -r "$SCRIPT_DIR/vscode-ext" "$HOME/.zsharp/" 2>/dev/null && print_success "VS Code extension installed" || true
cp -r "$SCRIPT_DIR/examples" "$HOME/.zsharp/" 2>/dev/null && print_success "Examples installed" || true

# Create command-line wrapper
print_info "Creating command-line interface..."

# Create the wrapper script
WRAPPER_SCRIPT="$HOME/.zsharp/zsharp-wrapper.py"
cat > "$WRAPPER_SCRIPT" << 'EOF'
#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.expanduser("~/.zsharp"))
from cli.zsharp_cli import main
if __name__ == "__main__":
    main()
EOF

chmod +x "$WRAPPER_SCRIPT"

# Create symlink in /usr/local/bin
if command -v sudo &> /dev/null; then
    # Check if we need sudo
    if [ -w /usr/local/bin ]; then
        ln -sf "$WRAPPER_SCRIPT" /usr/local/bin/zsharp
        print_success "Created /usr/local/bin/zsharp"
    else
        # Try with sudo
        sudo ln -sf "$WRAPPER_SCRIPT" /usr/local/bin/zsharp 2>/dev/null || {
            print_error "Could not create symlink in /usr/local/bin (permission denied)"
            print_info "You can manually add this to your PATH:"
            echo "export PATH=\"$HOME/.zsharp:$PATH\""
            exit 1
        }
        print_success "Created /usr/local/bin/zsharp (with sudo)"
    fi
else
    print_info "Creating wrapper in ~/.zsharp/bin..."
    mkdir -p "$HOME/.zsharp/bin"
    cat > "$HOME/.zsharp/bin/zsharp" << 'EOF'
#!/bin/bash
python3 "$HOME/.zsharp/zsharp-wrapper.py" "$@"
EOF
    chmod +x "$HOME/.zsharp/bin/zsharp"
fi

# Test installation
print_info "Testing installation..."
if command -v zsharp &> /dev/null; then
    VERSION=$(zsharp --version 2>/dev/null || echo "0.1.0")
    print_success "Z# is installed and working!"
    echo ""
    echo "Version: $VERSION"
else
    print_error "Installation failed - zsharp command not found"
    exit 1
fi

# Print instructions
echo ""
echo "========================================"
print_success "Installation Complete!"
echo "========================================"
echo ""
echo "Quick commands:"
echo "  zsharp run <file.z#>        Run a Z# program"
echo "  zsharp debug <file.z#>      Debug a program"
echo "  zsharp check <file.z#>      Check syntax"
echo "  zsharp create <project>     Create new project"
echo "  zsharp --help               Show all commands"
echo ""
echo "Try it out:"
echo "  zsharp run $HOME/.zsharp/examples/hello.z#"
echo ""
