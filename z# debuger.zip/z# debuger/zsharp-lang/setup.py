#!/usr/bin/env python3
"""
Setup script for Z# Language
Creates the macOS .app and installs the language
"""

from setuptools import setup, find_packages
import os

# Read README for long description
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="zsharp",
    version="0.1.0",
    author="Z# Team",
    author_email="contact@zsharp.dev",
    description="A simple programming language with VS Code debugging support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/zsharp/zsharp",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: MacOS :: MacOS 10.15",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Microsoft :: Windows",
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Languages",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "zsharp=cli.zsharp_cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "vscode-ext": [
            "**/*.json",
            "**/*.ts",
            "**/*.py",
            "syntaxes/*.json",
        ],
    },
)
