#!/bin/bash
# Build Z# as a macOS .app file

set -e

PROJECT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
BUILD_DIR="$PROJECT_DIR/build"
DIST_DIR="$PROJECT_DIR/dist"
APP_NAME="Z-Sharp"
APP_DIR="$DIST_DIR/$APP_NAME.app"

echo "Building Z# macOS .app file..."
echo "==============================="

# Check if PyInstaller is installed
if ! command -v pyinstaller &> /dev/null; then
    echo "Installing PyInstaller..."
    pip3 install pyinstaller
fi

# Clean previous builds
rm -rf "$BUILD_DIR" "$DIST_DIR" >/dev/null 2>&1 || true

# Create the main launcher script
LAUNCHER="$PROJECT_DIR/launcher.py"
cat > "$LAUNCHER" << 'EOF'
#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cli.zsharp_cli import main
if __name__ == "__main__":
    main()
EOF

# Build the .app using PyInstaller
echo "Creating .app bundle..."
pyinstaller \
    --name "$APP_NAME" \
    --onedir \
    --windowed \
    --icon="$PROJECT_DIR/assets/icon.icns" 2>/dev/null || \
pyinstaller \
    --name "$APP_NAME" \
    --onedir \
    --windowed \
    "$LAUNCHER"

# Copy additional resources
echo "Adding resources..."
cp -r "$PROJECT_DIR/compiler" "$DIST_DIR/$APP_NAME.app/Contents/Resources/"
cp -r "$PROJECT_DIR/vscode-ext" "$DIST_DIR/$APP_NAME.app/Contents/Resources/"
cp "$PROJECT_DIR/README.md" "$DIST_DIR/$APP_NAME.app/Contents/Resources/"

# Create InfoPlist.strings for localization
mkdir -p "$DIST_DIR/$APP_NAME.app/Contents/Resources/en.lproj"
cat > "$DIST_DIR/$APP_NAME.app/Contents/Resources/en.lproj/InfoPlist.strings" << 'EOF'
"CFBundleName" = "Z# Language";
"CFBundleShortVersionString" = "0.1.0";
"CFBundleGetInfoString" = "Z# Programming Language";
EOF

# Update the generated plist
PLIST="$DIST_DIR/$APP_NAME.app/Contents/Info.plist"
# Ensure the app has proper macOS metadata
if [ -f "$PLIST" ]; then
    /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string 'Z# Language'" "$PLIST" 2>/dev/null || true
    /usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string 'com.zsharp.lang'" "$PLIST" 2>/dev/null || true
    /usr/libexec/PlistBuddy -c "Add :CFBundleVersion string '0.1.0'" "$PLIST" 2>/dev/null || true
fi

# Create a command-line wrapper for easy installation
WRAPPER_DIR="$DIST_DIR/z-install"
mkdir -p "$WRAPPER_DIR"
cat > "$WRAPPER_DIR/install" << 'EOF'
#!/bin/bash
# Z# Installation Script

INSTALL_DIR="$HOME/.zsharp"
BIN_DIR="/usr/local/bin"

echo "Installing Z# Language..."
mkdir -p "$INSTALL_DIR"

# Copy app contents
APP_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )/Z-Sharp.app"

if [ ! -d "$APP_DIR" ]; then
    echo "Error: Z-Sharp.app not found"
    exit 1
fi

cp -r "$APP_DIR/Contents/Resources"/* "$INSTALL_DIR/" 2>/dev/null || true

# Create command-line tool
sudo tee "$BIN_DIR/zsharp" > /dev/null << 'ZSHARP_EOF'
#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.expanduser("~/.zsharp"))
from cli.zsharp_cli import main
if __name__ == "__main__":
    main()
ZSHARP_EOF

sudo chmod +x "$BIN_DIR/zsharp"

echo "Installation complete!"
echo "Use: zsharp run <file.z#>"
echo "Or:  zsharp --help"
EOF

chmod +x "$WRAPPER_DIR/install"

# Create a symbolic link to the app for easy access
ln -sf "$APP_DIR" "$DIST_DIR/$APP_NAME"

echo ""
echo "✓ Build complete!"
echo ""
echo "Output:"
echo "  - $APP_DIR"
echo "  - $DIST_DIR/$APP_NAME (symlink)"
echo ""
echo "To install and use Z#:"
echo "  1. Copy $APP_DIR to /Applications"
echo "  2. Run: $WRAPPER_DIR/install"
echo "  3. Use: zsharp run <file.z#>"

# Clean up launcher
rm -f "$LAUNCHER"
