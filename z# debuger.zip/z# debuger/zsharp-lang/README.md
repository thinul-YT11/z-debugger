# Z# Programming Language
**A simple and elegant programming language with VS Code debugging support**

## Features
- ✨ Simple, readable syntax
- 🐛 Full VS Code debugger integration  
- 🚀 Fast compilation and execution
- 📦 Easy installation via command line

## Installation

### macOS (using .app)
1. Download `Z-Sharp.app` from releases
2. Move to Applications folder
3. Open Terminal and run:
```bash
z install zsharp
```

### Manual Installation
1. Clone this repository
2. Run the installation script:
```bash
./install.sh
```

## Quick Start

### Create a Z# file
Create a file named `hello.z#`:
```z#
include(zsharp)

get p*Hello, World!*
```

### Run the file
```bash
zsharp run hello.z#
```

### Start debugging
In VS Code, open the command palette and search for "Z#: Start Debugger"

## Language Syntax

### Print Output
```z#
get p*text*
```

### Variables
```z#
name = *Alice*
age = 25
```

### Loops
```z#
loop 5 {
    get p*Hello*
}
```

### Conditional Statements
```z#
check (age > 18) {
    get p*Adult*
}
```

### Functions
```z#
func greet(name) {
    get p*Hello, *
    get p*name*
}

greet(*Bob*)
```

### Include Libraries
```z#
include(zsharp)
include(math)
```

## Commands

```bash
# Run a Z# file
zsharp run myfile.z#

# Build to bytecode
zsharp build myfile.z#

# Check syntax
zsharp check myfile.z#

# Debug interactively
zsharp debug myfile.z#

# Create new project
zsharp create myproject
```

## VS Code Extension

The Z# debugger extension provides:
- Syntax highlighting
- Code completion
- Debugging with breakpoints
- Variable inspection
- Call stack navigation
- Hover documentation

## Examples

See the `examples/` directory for sample programs.

## License
MIT

## Contributing
Contributions welcome! Please submit pull requests to the main repository.
