#!/bin/bash
# Z# Language Installation Script for macOS

set -e

INSTALL_DIR="$HOME/.zsharp"
BIN_DIR="/usr/local/bin"

echo "Z# Language Installation"
echo "======================="

# Create installation directory
mkdir -p "$INSTALL_DIR"

# Get the path where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Copy compiler and CLI files
echo "Installing Z# compiler..."
cp -r "$SCRIPT_DIR/compiler" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/cli" "$INSTALL_DIR/"
cp -r "$SCRIPT_DIR/vscode-ext" "$INSTALL_DIR/"

# Create wrapper scripts
echo "Creating command-line interface..."

cat > "$BIN_DIR/zsharp" << 'EOF'
#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.expanduser("~/.zsharp"))
from cli.zsharp_cli import main
if __name__ == "__main__":
    main()
EOF

chmod +x "$BIN_DIR/zsharp"

# Install VS Code extension
if command -v code &> /dev/null; then
    echo "Installing VS Code extension..."
    # This would typically be installed through the VS Code marketplace
    # For now, we'll create a link
    code --install-extension "$INSTALL_DIR/vscode-ext/zsharp-debugger"
fi

echo ""
echo "Installation complete!"
echo "You can now use: zsharp run <file.z#>"
echo "Or: zsharp --help for more commands"
